# My First Project > 2025-02-02 12:42am
https://universe.roboflow.com/test-ul13l/my-first-project-fqqce

Provided by a Roboflow user
License: CC BY 4.0

